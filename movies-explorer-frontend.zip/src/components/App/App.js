import './App.css';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';
import Main from '../Main/Main';
import MoviesCardList from '../Movies/MoviesCardList';
import SavedMoviesCardList from '../SavedMovies/MoviesCardList/MoviesCardList';
import Login from '../Modal/Login/Login';
import Register from '../Modal/Register/Register';
import Profile from '../Modal/Profile/Profile';
import NotFound from '../404/NotFound';
import { useState } from 'react';
import { Route, Switch, useHistory} from 'react-router';
import * as auth from '../../utils/auth';
import close from '../../images/close.png';
import account from '../../images/account.png';
import ProtectedRoute from '../ProtectedRoute/ProtectedRoute';
import {mainApi} from '../../utils/MainApi';

function App() {
  const history=useHistory();
  const [movies,setMovies]=useState([]);
  const [savedMovies,setSavedMovies]=useState([]);
  const [isMain,setIsMain]=useState(false);
  const [isMovie,setIsMovie]=useState(false);
  const [isSavedMovie,setIsSavedMovie]=useState(false);
  const [isProfile,setIsProfile]=useState(false);
  const isMovieOrProfile = isMovie || isSavedMovie || isProfile;
  const isLoginOrRegister = !isMain && !isMovie && !isSavedMovie && !isProfile;
  const [isPopupOpen,setIsPopupOpen]=useState(false);

  const [loggedIn, setLoggedIn] = useState(false);

  function handleFailedLogin(){
    alert('Что-то пошло не так! Попробуйте еще раз.')
  }

  function handleLogin (email, password){
    auth.authorize(email, password, handleFailedLogin)
    .then((data) => {
      if (data.token){
        const newPromise = new Promise(function (resolve, reject) {
          resolve(setLoggedIn(true))
        })
        newPromise
        .then(function (value) { 
          alert('logg is '+loggedIn)
          history.push('/movies');
          history.go();
        })
      } 
    })   
    .catch(err => console.log(err));
  }

  // function handleLogin (email, password){
  //   auth.authorize(email, password, handleFailedLogin)
  //   .then((data) => {
  //     console.log(data)
  //     if (data.token){
  //       setLoggedIn(true)
  //       alert('log' + loggedIn)
  //       history.push('/movies');
  //       history.go();
  //     }
  //   })  
  //   .catch(err => console.log(err));
  // }


  if (movies.length === 0){
    setMovies([{country: "Zimbabve", director:'Smith', "duration": 4,
        "year": "1994",
        "description": "topa-topa-topa",
        "image": "http://yandex.ru",
        "trailer": "http://yandex.ru",
        "thumbnail": "http://yandex.ru",
        "movieId": 1,
        "nameRU": "NAMEru",
        "nameEN": "NAMEen"},
      {name:'namen',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'111',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://sun6-22.userapi.com/impf/zlJwszlG77CnUNz8gAw-1WqJpVU3tnQiBwOo_Q/HbJXFyynflI.jpg?size=1280x800&quality=96&sign=55da32cf936194b1fd6a61f45788c0bb&c_uniq_tag=6r89xpKgaNM1LgQER524ZhLDZevDD0GVGrrDIGkje-s&type=album',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://sun9-26.userapi.com/impg/xUMdNvbr5Cq6AVwMjODCxHfZqd3p7BZ4y5HIDA/5V3oYbt5GGw.jpg?size=270x151&quality=96&sign=38d12eaa1f513a4b22c5cebadee29bbd&type=album',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},])
  }
  if (savedMovies.length === 0){
    setSavedMovies([{country: "Zimbabve", director:'Smith', "duration": 4,
    "year": "1994",
    "description": "topa-topa-topa",
    "image": "http://yandex.ru",
    "trailer": "http://yandex.ru",
    "thumbnail": "http://yandex.ru",
    "movieId": 1,
    "nameRU": "NAMEru",
    "nameEN": "NAMEen"},
      {name:'namen',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'111',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://sun6-22.userapi.com/impf/zlJwszlG77CnUNz8gAw-1WqJpVU3tnQiBwOo_Q/HbJXFyynflI.jpg?size=1280x800&quality=96&sign=55da32cf936194b1fd6a61f45788c0bb&c_uniq_tag=6r89xpKgaNM1LgQER524ZhLDZevDD0GVGrrDIGkje-s&type=album',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://sun9-26.userapi.com/impg/xUMdNvbr5Cq6AVwMjODCxHfZqd3p7BZ4y5HIDA/5V3oYbt5GGw.jpg?size=270x151&quality=96&sign=38d12eaa1f513a4b22c5cebadee29bbd&type=album',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},
      {name:'namen1',link:'https://i.mycdn.me/i?r=AzEPZsRbOZEKgBhR0XGMT1Rk3xj3SNsykl6tc1aFKIVZ6aaKTM5SRkZCeTgDn6uOyic',numberOfLikes:0,cardId:'112',elementLikes:[],ownerID:'2222',likes:[],length:'1ч 42м'},])
  }


  
  function onRegisterClick(){
    history.push('/sign-up');
    history.go();
  }
  function onLoginClick(){
    history.push('/sign-in');
    history.go();
  }
  function onMoviesClick(){
    history.push('/movies');
    history.go();
  }
  function onSavedMoviesClick(){
    history.push('/saved-movies');
    history.go();
  }
  function onProfileClick(){
    history.push('/profile');
    history.go();
  }
  function onLogOutClick(){
    history.push('/');
    history.go();
  }
  function onNotFound(){
    history.go(-1);
  }
  function closePopup(){
    setIsPopupOpen(false);
  }

  function handleRegister(name,password,email){
    auth.register(name,  password, email).then((res) => {
      if(res){
          alert('Вы успешно зарегистрировались, ' + name)
          history.push('/sign-in');
      } else {
        alert('Something gone wrong')
      }
    })
    .catch(err => console.log(err));
  }

  function checkToken () {
    const token = localStorage.getItem('token');
    if (token){
      auth.getContent(token).then((res) => {
        if (res){
          setLoggedIn(true)
          history.push('/');
        };
      })
      .catch((err) => {
        console.log(err); 
      });
    }    
  }

  function handleUpdateUser(name, email) {
    mainApi.postLoginToServer(name, email)
      .then((updatedUser)=>{
        alert('Профиль успешно обновлен! Привет, '+ updatedUser.data);
      })
      .catch((err) => {
        console.log(err); 
      });
  }

  const [cards,setCards]=useState([]);

  function prepareCard(newCard){
    const name=newCard.name;
    const link=newCard.link;
    const numberOfLikes=newCard.likes.length;
    const likes=newCard.likes;
    const cardId=newCard._id;
    const elementLikes = newCard.likes
    const ownerID = newCard.owner;
    return {name,link,numberOfLikes,cardId,elementLikes,ownerID,likes}
  }

  function handleApploadCard(data) {
    alert('1 '+ data.director)
    // mainApi.postCardToServer(data.country, data.director, data.duration, data.year, data.description, data.image, data.trailer, data.thumbnail, data.movieId, data.NAMEru, data.nameEN )
    mainApi.postCardToServer(data)  
      // .then((newCard)=>{
      //   const newCardToPage = prepareCard(newCard.data)
      //   setCards([newCardToPage, ...cards]); 
      // })
      .catch((err) => {
        console.log(err); 
      });
  }

  return (
    <div className="App">
        <Header isLoginOrRegister={isLoginOrRegister} isMain={isMain} isMovie={isMovie} isSavedMovie={isSavedMovie} isMovieOrProfile={isMovieOrProfile} onRegisterClick={onRegisterClick} onLoginClick={onLoginClick} onMoviesClick={onMoviesClick} onSavedMoviesClick={onSavedMoviesClick} onProfileClick={onProfileClick} setIsPopupOpen={setIsPopupOpen}/>
        <Switch>
          <Route path="/sign-up">
            <Register onLoginClick={onLoginClick} setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile} handleRegister={handleRegister} />
          </Route>
          <Route path="/sign-in">
            < Login onRegisterClick={onRegisterClick} setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile} handleLogin={handleLogin} />
          </Route>
          <ProtectedRoute path="/movies" loggedIn={loggedIn} 
            component={()=>(<MoviesCardList movies={movies} setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile}/>)} />
          {/* <Route path="/movies">
            <MoviesCardList movies={movies} setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile} handleApploadCard={handleApploadCard} />
          </Route> */}
          <Route path="/saved-movies">
            <SavedMoviesCardList movies={savedMovies} setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile} />
          </Route>
          <Route path="/profile">
            <Profile onLogOutClick={onLogOutClick} setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile} handleUpdateUser={handleUpdateUser} />
          </Route>
          <Route exact path="/">
            <Main setIsMain={setIsMain} setIsSavedMovie={setIsSavedMovie} setIsMovie={setIsMovie} setIsProfile={setIsProfile} />
          </Route>
          <Route path="*">
            <NotFound onNotFound={onNotFound} setIsMain={setIsMain}  />
          </Route>
      
        </Switch>
        <Footer />
        <div className={`popup ${isPopupOpen?'popup_visible':''} `}>
          <div className='popup__field'>
            <div className="popup__buttonField">
              <button className='popup__buttonClose' onClick={closePopup}><img className='popup__closeImg' src={close} alt='Закрыть' /></button> 
            </div>
            <div className='popup__container'>
              <button id="utton" type='button' onClick={onLogOutClick} className={`popup__button ${isMain?'popup__button_highlighted':''}`}> Главная </button>
              <button id="utton" type='button' onClick={onMoviesClick} className={`popup__button ${isMovie?'popup__button_highlighted':''}`}> Фильмы </button>
              <button id="utton" type='button' onClick={onSavedMoviesClick} className={`popup__button ${isSavedMovie?'popup__button_highlighted':''}`}> Сохраненные фильмы</button>
            </div>
            <button id="utton" type='button' onClick={onProfileClick} className="popup__button popup__button_account"> Аккаунт <img className="header__accountArt" src={account} alt="Аккаунт"/></button>
          </div>
        </div>
    </div>
  );
}

export default App;
